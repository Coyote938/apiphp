package com.example.revisarvista;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final String API_URL = "http://localhost/api.php";
    private ArrayList<String> tasks;
    private ArrayAdapter<String> adapter;
    private EditText editText;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        listView = findViewById(R.id.listView);

        Button addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = editText.getText().toString();
                if (!title.isEmpty()) {
                    AddTaskAsyncTask addTaskAsyncTask = new AddTaskAsyncTask();
                    addTaskAsyncTask.execute(title);
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a task title", Toast.LENGTH_SHORT).show();
                }
            }
        });

        tasks = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tasks);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String task = tasks.get(position);
                ToggleTaskCompletionAsyncTask toggleTaskCompletionAsyncTask = new ToggleTaskCompletionAsyncTask();
                toggleTaskCompletionAsyncTask.execute(task);
            }
        });

        FetchTasksAsyncTask fetchTasksAsyncTask = new FetchTasksAsyncTask();
        fetchTasksAsyncTask.execute();
    }
}

private class AddTaskAsyncTask extends AsyncTask<String, Void, String> {

    @Override
    protected String doInBackground(String... strings) {
        String title = strings[0];
        try {
            URL url = new URL(API_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            JSONObject jsonBody = new JSONObject();
            jsonBody.put("title", title);

            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(jsonBody.toString().getBytes());
            outputStream.close();

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                return response.toString();
            } else {
                Log.e("AddTask", "Error: " + responseCode);
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String response) {
        if (response != null) {
            try {
                JSONObject jsonObject = new JSONObject(response);
                String title = jsonObject.getString("title");
                tasks.add(title);
                adapter.notifyDataSetChanged();
                editText.setText("");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(MainActivity.this, "Failed to add task", Toast.LENGTH_SHORT).show();
        }
    }
}

private class ToggleTaskCompletionAsyncTask extends AsyncTask<String, Void, Boolean> {

    @Override
    protected Boolean doInBackground(String... strings) {
        String task = strings[0];
        try {
            URL url = new URL(API_URL + "?task=" + task);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("PUT");

            int responseCode = connection.getResponseCode();
            return responseCode == HttpURLConnection.HTTP_OK;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    protected void onPostExecute(Boolean success) {
        if (success) {
            adapter.notifyDataSetChanged();
        } else {
            Toast.makeText(MainActivity.this, "Failed to toggle task completion", Toast.LENGTH_SHORT).show();
        }
    }
}
}