package com.example.todolist;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

import kotlinx.coroutines.scheduling.Task;

public class MainActivity extends AppCompatActivity {
    private EditText editTextTitle;
    private Button buttonAddTask;
    private Button buttonRefreshTasks;
    private ListView listViewTasks;
    private TaskAdapter taskAdapter;
    private RequestQueue requestQueue;
    private static final String API_URL = "http://tu-api-php/todo-list-api.php";

    private List<Task> taskList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextTitle = findViewById(R.id.editTextTitle);
        buttonAddTask = findViewById(R.id.buttonAddTask);
        buttonRefreshTasks = findViewById(R.id.buttonRefreshTasks);
        listViewTasks = findViewById(R.id.listViewTasks);

        requestQueue = Volley.newRequestQueue(this);
        taskAdapter = new TaskAdapter(this, taskList);
        listViewTasks.setAdapter(taskAdapter);

        buttonAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = editTextTitle.getText().toString().trim();
                if (!title.isEmpty()) {
                    addTask(title);
                } else {
                    Toast.makeText(MainActivity.this, "Ingrese un título", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonRefreshTasks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshTasks();
            }
        });

        // Cargar las tareas al iniciar la actividad
        refreshTasks();
    }

    private void addTask(String title) {
        JSONObject requestData = new JSONObject();
        try {
            requestData.put("title", title);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, API_URL, requestData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Toast.makeText(MainActivity.this, "Tarea agregada", Toast.LENGTH_SHORT).show();
                        editTextTitle.setText("");
                        refreshTasks();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "Error al agregar tarea", Toast.LENGTH_SHORT).show();
                        Log.e("API Error", error.toString());
                    }
                });

        requestQueue.add(request);
    }

    private void refreshTasks() {
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, API_URL, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        // Limpiar la lista de tareas existente
                        taskList.clear();

                        // Procesar el arreglo de tareas JSON y agregarlas a la lista
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                JSONObject taskData = response.getJSONObject(i);
                                int id = taskData.getInt("id");
                                String title = taskData.getString("title");
                                boolean completed = taskData.getBoolean("completed");

                                Task task = new Task(id, title, completed);
                                taskList.add(task);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        // Notificar al adaptador que los datos han cambiado
                        taskAdapter.notifyDataSetChanged();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "Error al obtener tareas", Toast.LENGTH_SHORT).show();
                        Log.e("API Error", error.toString());
                    }
                });

        requestQueue.add(request);
    }
}
